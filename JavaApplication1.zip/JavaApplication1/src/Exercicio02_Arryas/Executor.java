/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio02_Arryas;

import sun.applet.Main;

/**
 *
 * @author 631510045
 */
public class Executor {
    public static void main(String[] args) {
        CreateData c = new CreateData();
        c.create2DArray();
    }
}
