/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio02_Arryas;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
/**
 *
 * @author 631510045
 */
public class CreateData {
    Random r = new Random();
    /**
     * Print the multi array
     */
   public void create2DArray(){ 
        int[][] multi = new int[8][10];
        int[][] result = insertDataOn2DArray(multi);
            System.out.println(Arrays.deepToString(result));
        }
    /**
     * Fill the multi[][] with  number betwen 0 and 1
     * @param multi
     * @return 
     */
    public int[][] insertDataOn2DArray(int[][] multi) {
        for (int i = 0; i < multi.length; i++) {
                 for (int j = 0; j < multi[i].length; j++) {
        multi[i][j] = (int)(r.nextInt(2));
    }
}
        return multi;
    }

}
