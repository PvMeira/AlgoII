/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio01_Arrays;

/**
 *
 * @author 631510045
 */
public class ExercicioPrint {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        Exercicio ex = new Exercicio();
     int[] r = ex.fillTheArray();   
    ex.printMaxNumber(r);
    ex.printLowNumber(r);
    //Average result on the iterable array
    ex.printAverageValue(r);
    }
    
}
