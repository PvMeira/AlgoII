/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio03_Arrays;

import java.util.Random;

/**
 *
 * @author 631510045
 */
public class CreateData03 {
    public int [] createRandomArray(){
        int [] result = new int [10];
        result = fillArray(result);
        return result;
    }
//    public int getSum(){
//        
//    }
    public void printArray(int[] r){
        for (int i = 0; i < r.length; i++) {
            System.out.println(r[i]);
        }
    }
    public int[] fillArray(int [] result){
        for (int i = 0; i < result.length; i++) {
           result[i] = createRandomNumber();           
        }
        
     return result;   
    }
    public int createRandomNumber(){
        Random r = new Random();
        int Low = -10;
        int High = +10;
        int Result = r.nextInt(High-Low) + Low;
        return Result;
    }
}
